README for hw4-Lopez.zip

* Melissa Lopez *

(1) Date: Tuesday, April 18, 2017

(2) Class Info: Homework #3, Introduction to Robotics, Spring 2017

(3) Group Members: Eshan Saran

(4) N16365076

(5) SOURCE STATEMENT: This homework assignment contains a lot of code that is not my own, since it was provided for the assignment by the TAs and Professor Yap. The Environment.m file contains most of my own work, instead of using the solution that was already provided to us. As for the other files, I really wrestled with them to no avail, so they're pretty incomplete.

(6) ORIGINALITY STATEMENT: "This writeup is my own work alone, referencing only the sources described in the SOURCE STATEMENT above. Electronically signed: Melissa Lopez."



