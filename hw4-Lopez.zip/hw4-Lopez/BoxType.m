classdef BoxType <  int32
    enumeration
        FREE(1)
        MIXED(0)
        STUCK(-1)
    end
end
